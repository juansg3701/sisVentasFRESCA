<?php
//$mysqli = new mysqli("localhost", "root", "", "final");
$mysqli = new mysqli("remotemysql.com","MTvDp0bqcd","SxQzQi4dyT","MTvDp0bqcd");