<?php
$mysqli = new mysqli("remotemysql.com","FzhnWzfWhw","4lwAqoEP8s","FzhnWzfWhw");