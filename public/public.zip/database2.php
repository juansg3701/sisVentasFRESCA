<?php
// parametros: host,user,password,database
//$con = new mysqli("controler.com.co","control3_cosechafresca1","ctj9jN7ePPt@","control3_cosechafresca1");
$con = new mysqli("remotemysql.com","MTvDp0bqcd","SxQzQi4dyT","MTvDp0bqcd");
//$con = new mysqli("localhost","root","","fzhnwzfwhw");
?>