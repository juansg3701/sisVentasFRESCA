<?php
// Connection variables
$dbhost	= "127.0.0.1";	   // localhost or IP
$dbuser	= "root";		  // database username
$dbpass	= "";		     // database password
$dbname	= "posbd";    // database name
?>
