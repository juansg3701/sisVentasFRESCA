<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="modal-datafono-{{$f->id_factura}}">


	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
						<head>
				
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
			    <!--<link rel="stylesheet" href="{{ asset('css/Almacen/usuario/styles-iniciar.css') }}" />-->
			</head>
			<body>
				<div class="row">
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
						<h3>Pago datafono</h3>
					</div>
				</div>



				<div id=formulario>
					<div class="form-group">
					
						<div align="center">
						<button class="btn btn-info" type="submit">Pago realizado</button>
						</div>
					</form>

						<br>
					

						Devolver<input type="text" class="form-control" value="<?php ?>">
								</div>
						
					</div>
				</div>
				<div align="center">
			<a href="">

						<button class="btn btn-info" >Pagar</button></a>	
					</div>
			</body>
		</div>	
		</div>
	</div>

</div>